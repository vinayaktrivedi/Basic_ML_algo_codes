#For running the both codes, the test data, training data and class attributes data of both seen and unseen class must be present in the same directory as the python files.

#For running first model, based on convex combination of means of seen classes, simply run-
"python convex.py" in the directory file is located. 

#For running the second model based on regression, simply run-
"python regress.py" in the directory file is located.

#Only numpy library is used, so need to install other libraries or packages.

#Accuracy is printed to the standard output- terminal console. 

#No argument needs to be given to the codes. Also, note that test data, training data or class attributes must be present in form .npy and with same names as used in the code. 



